from django.contrib import admin
from .models import DataInformation
admin.site.register(DataInformation) 


